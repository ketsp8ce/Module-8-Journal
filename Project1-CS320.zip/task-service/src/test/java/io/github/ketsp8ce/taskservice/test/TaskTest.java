package io.github.ketsp8ce.taskservice.test;


import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import io.github.ketsp8ce.taskservice.main.Task;

class TaskTest {
	


	//test creating a task object
	@Test
	@DisplayName ("Test to create a new task object")
	void testCreateTask() {
	Task task = new Task("123456789", "catch the turtle", "We must catch a turtle");
	assertEquals("123456789", task.getTaskID());
	assertEquals("catch the turtle", task.getName());
	assertEquals("We must catch a turtle", task.getDescription());
	}


	//test ID too long?
	@Test
	@DisplayName ("taskID cannot be more than 10 characters")
	void testTaskIDMoreThanTenCharacters() {
	Task task = new Task("123456789123456789", "catch the turtle", "We must catch the turtle");
	if (task.getTaskID().length() > 10) {
	fail("taskID has more than 10 characters");
	}
	}

	//test name too long
	@Test
	@DisplayName ("task name cannot be more than 20 characters")
	void testNameMoreThanTwentyCharacters() {
	Task task = new Task("123456789", "catch the turtle and name it Franklin", "We must catch the turtle");
	if (task.getName().length() > 20) {
	fail("name has more than 20 characters");
	}
	}

	//its description too long
	@Test
	@DisplayName ("description cannot be more than 50 characters")
	void testDescriptionMoreThanFiftyCharacters() {
	Task task = new Task("123456789", "catch the turtle", "We must catch the turtle and name it supercalafragalisticexpialadocious");
	if (task.getDescription().length() > 50) {
	fail("description has more than 50 characters");
	}
	}
	
	
}



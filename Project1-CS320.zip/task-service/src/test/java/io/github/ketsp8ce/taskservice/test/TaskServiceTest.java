/**
 * 
 */
package io.github.ketsp8ce.taskservice.test;


import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

import io.github.ketsp8ce.taskservice.main.Task;
import io.github.ketsp8ce.taskservice.main.TaskService;

/**
 * 
 */
class TaskServiceTest {
	
	//test adding a single task
	@Test
	  public void testAddTask() {
	        TaskService service = new TaskService();
	        service.addTask("111111111", "Climb Mountain", "we must climb the mountain");
	        assertNotNull(service.getTask("111111111")); 
	    }

	
	
	//test adding multiple tasks
	@Test
	public void testAddMultipleTasks() {
			TaskService service = new TaskService();
		
			//adding multiple tasks
			service.addTask("111", "Task1", "description 1");
			service.addTask("222", "Task2", "description 2");
			service.addTask("333", "Task3", "description 3");
			
			//verifying all the added tasks
			assertNotNull(service.getTask("111"));
			assertNotNull(service.getTask("222"));
			assertNotNull(service.getTask("333"));
		
	}
	
	
	//Test if an error occurs when adding a task with a duplicate ID
	@Test
	public void testDuplicateId() {
		TaskService service = new TaskService();
		service.addTask("444", "Task4", "description 4");
		
		//attempt to add a task with a duplicate id
		assertThrows(IllegalArgumentException.class, () -> {
			service.addTask("444", "task5", "description 5");
		});
	}
	
	//Test adding and getting a task back from the service
	@Test
	public void testAddAndGetTask() {
		TaskService service = new TaskService();
		service.addTask("123", "grocery shop", "shop for groceries");

	    Task gottenTask = service.getTask("123");
	    assertNotNull(gottenTask);
	    
	    assertEquals("grocery shop", gottenTask.getName());
	    assertEquals("shop for groceries", gottenTask.getDescription());
	    
	}
	
	//test updating a test
	@Test
    public void testUpdateName() { //by name
        TaskService service = new TaskService();
        service.addTask("111111111", "Climb Mountain", "we must climb the mountain");
        service.updateName("111111111", "Ski Mountain");
        assertEquals("Yoga", service.getTask("T1").getName());
    }
	
	@Test
    public void testUpdateDescription() { //by description
        TaskService service = new TaskService();
        service.addTask("111111111", "Climb Mountain", "we must climb the mountain");
        service.updateDescription("111111111", "Climb Mountain");
        assertEquals("Yoga", service.getTask("T1").getName());
    }
	
	//test deleting a test
    @Test
    public void testDeleteTask() {
        TaskService service = new TaskService();
        service.addTask("111111111", "Climb Mountain", "we must climb the mountain");
        service.deleteTask("111111111");
        assertNull(service.getTask("111111111"));
	}
    
}



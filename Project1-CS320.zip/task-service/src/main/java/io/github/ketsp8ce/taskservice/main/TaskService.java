//Author Name: Hunter Marx

//Date: 03/30/2025

//Course ID: CS320-10813-M01

//Description: This is the task service class. It has methods to add, delete, and update the tasklist.
//See the Constructor for more info.



package io.github.ketsp8ce.taskservice.main;
import java.util.ArrayList;

public class TaskService {

	//Start with an ArrayList of tasks to hold the list of tasks
	ArrayList<Task> taskList = new ArrayList<Task>();
	
	
	//Display the full list of tasks to the console for error checking.
	public void displayTaskList() {
	for(int counter = 0; counter < taskList.size(); counter++) {
	System.out.println("\t Task ID: " + taskList.get(counter).getTaskID());
	System.out.println("\t First Name: " + taskList.get(counter).getName());
	System.out.println("\t Last Name: " + taskList.get(counter).getDescription());
	}
	}
	
	//Adds a new task using the Task constructor, then assign the new task to the list.
	public void addTask(String taskID, String name, String description) {
	//Create the new task
		Task task = new Task(taskID, name, description);
		taskList.add(task);
		}

	public void deleteTask(String taskID) {
		//Deletes a task
		for (int i = 0; i < taskList.size(); i++) {  //iterates through task array list and checks the address
		if (taskList.get(i).getTaskID().equals(taskID)) { //if a given element in the task array list matches the value at the address for task id, delete it  
			taskList.remove(i);
			return;
		}
		}
	}

	//update various fields
	public void updateName (String taskID, String updatedName) {
		for (Task task : taskList) { //iterate through each task object in the taskList array
			if (task.getTaskID().equals(taskID)) { //when it finds the specified taskID
				task.setName(updatedName); //update the name field for that Task object
			}
		}
	}
	public void updateDescription (String taskID, String updatedDescription) {
		for (Task task : taskList) {//iterate through each task object in the taskList array
			if (task.getTaskID().equals(taskID)) { //when it finds the specified taskID
				task.setDescription(updatedDescription); //update the description field for that Task object
			}
		}
	}

		
		public Task getTask(String taskID) { //method to retrieve a given task object
		    for (Task task : taskList) { //iterate through task list
		        if (task.getTaskID().equals(taskID)) { //when we find the match .....
		            return task; //return the information stored in its address
		        }
		    }
		    return null;
		}

		public ArrayList<Task> getTaskList() {
		    return taskList;
		}



}

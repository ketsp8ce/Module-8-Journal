//Author Name: Hunter Marx

//Date: 03/30/2025

//Course ID: CS320-10813-M01

//Description: This is the task class. It creates and stores Tasks
//See the Constructor for more info.


package io.github.ketsp8ce.taskservice.main;
import java.util.concurrent.atomic.AtomicLong;


public class Task {
	
private final String taskID;
private String name;
private String description;
private static AtomicLong idGenerator = new AtomicLong();



//CONSTRUCTOR

public Task(String taskID, String name, String description) {
	
	//TASKID
	this.taskID = String.valueOf(idGenerator.getAndIncrement());
	
	//NAME
	if (name == null || name.isBlank()) {
	this.name = "NULL";
	//If first name is longer than 20 characters, just grab the first 10 characters
	} else if(name.length() > 20) {
	this.name = name.substring(0, 20);
	} else {
	 this.name = name;
	}
	
	//DESCRIPTION
	if (description == null || description.isBlank()) {
	this.description = "NULL";
	} else if(description.length() > 50 ) {
		this.description = description.substring(0, 50);
	} else {
		this.description = description;
	}
	
}

//GETTERS
public String getTaskID() {
	return taskID;
}
public String getName() {
	return name;
}
public String getDescription() {
	return description;
}

//SETTERS
public void setName(String name) {
	this.name = (name == null || name.isBlank()) ? "NULL" :
        name.substring(0, Math.min(name.length(), 20));
}

public void setDescription(String description) {
	this.description = (description == null || description.isBlank()) ? "NULL" :
		description.substring(0, Math.min(description.length(), 50));
}

}